import FCT_2024

FCT_2024.run()