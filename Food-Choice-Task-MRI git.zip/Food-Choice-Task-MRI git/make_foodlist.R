#read in data
dat <- read.csv("~/Dropbox/mTurk/nutrient_info.csv")
dat <- subset(dat, dat$Study == "REFCT")
foods <- read.csv("~/Downloads/Food-Choice-Task-MRI/lists/foodlist1.csv")

lf <- dat %>% arrange(Fat_pctKcal) %>% dplyr::top_n(30,Fat_pctKcal)
hf <- dat %>% arrange(desc(Fat_pctKcal)) %>% dplyr::top_n(30,Fat_pctKcal)

foodlist <- rbind(hf,lf)
write.csv(foodlist, "~/Downloads/Food-Choice-Task-MRI/lists/HF_LF.csv"))
