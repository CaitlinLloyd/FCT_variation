import FCT_pref_2024_behav

FCT_pref_2024_behav.run()